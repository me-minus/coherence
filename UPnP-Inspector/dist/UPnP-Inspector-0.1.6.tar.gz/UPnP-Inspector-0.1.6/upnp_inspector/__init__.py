# -*- coding: utf-8 -*-

__version_info__ = (0,1,6)
__version__ = '%d.%d.%d' % (__version_info__[0],__version_info__[1],__version_info__[2],)
